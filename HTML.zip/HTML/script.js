// Cipher to Silicon - Main JavaScript

// ========== NAVIGATION ==========
function initNavigation() {
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const section = this.getAttribute('data-section');
            showSection(section);
        });
    });
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('section').forEach(section => {
        section.classList.remove('active');
    });
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
}

// ========== CIPHER LAB ==========
function encryptMessage() {
    const message = document.getElementById('messageInput').value.toUpperCase();
    const rotor1 = parseInt(document.getElementById('rotor1').value) || 0;
    const rotor2 = parseInt(document.getElementById('rotor2').value) || 0;
    const rotor3 = parseInt(document.getElementById('rotor3').value) || 0;

    if (!message) {
        alert('Please enter a message to encrypt');
        return;
    }

    let encrypted = '';
    const keystrokes = [];

    for (let char of message) {
        if (char >= 'A' && char <= 'Z') {
            let charCode = char.charCodeAt(0) - 65;
            charCode = (charCode + rotor1 + rotor2 + rotor3) % 26;
            const encryptedChar = String.fromCharCode(charCode + 65);
            encrypted += encryptedChar;
            keystrokes.push(`${char} → [Rotor I:${rotor1}] → [Rotor II:${rotor2}] → [Rotor III:${rotor3}] → ${encryptedChar}`);
        } else {
            encrypted += char;
        }
    }

    const output = document.getElementById('encryptedOutput');
    output.textContent = encrypted;
    output.classList.add('glow');
    setTimeout(() => output.classList.remove('glow'), 600);

    // Show keystroke animation
    showKeystrokeAnimation(keystrokes);

    // Update rotor visualization
    updateRotorVisualization(rotor1, rotor2, rotor3);
}

function resetSimulator() {
    document.getElementById('messageInput').value = '';
    document.getElementById('rotor1').value = '0';
    document.getElementById('rotor2').value = '0';
    document.getElementById('rotor3').value = '0';
    document.getElementById('encryptedOutput').textContent = 'Output appears here...';
    const animationDiv = document.getElementById('keystrokeAnimation');
    if (animationDiv) animationDiv.innerHTML = '';
}

function updateRotorVisualization(r1, r2, r3) {
    const rotor1Display = document.getElementById('rotor1Display');
    const rotor2Display = document.getElementById('rotor2Display');
    const rotor3Display = document.getElementById('rotor3Display');

    if (rotor1Display) rotor1Display.textContent = String(r1).padStart(2, '0');
    if (rotor2Display) rotor2Display.textContent = String(r2).padStart(2, '0');
    if (rotor3Display) rotor3Display.textContent = String(r3).padStart(2, '0');
}

function showKeystrokeAnimation(keystrokes) {
    let animationDiv = document.getElementById('keystrokeAnimation');
    if (!animationDiv) {
        animationDiv = document.createElement('div');
        animationDiv.id = 'keystrokeAnimation';
        animationDiv.className = 'keystroke-animation';
        document.querySelector('.simulator-container').insertBefore(
            animationDiv,
            document.querySelector('.button-group')
        );
    }

    animationDiv.innerHTML = '';
    keystrokes.forEach((keystroke, index) => {
        setTimeout(() => {
            const event = document.createElement('div');
            event.className = 'keystroke-event';
            event.textContent = keystroke;
            animationDiv.appendChild(event);
            animationDiv.scrollTop = animationDiv.scrollHeight;
        }, index * 100);
    });
}

// ========== TIMELINE MODAL ==========
const timelineData = [
    {
        title: 'Caesar Cipher (c. 50 BCE)',
        body: 'The Caesar cipher is one of the earliest known substitution systems. By shifting letters by a fixed amount, it introduces a repeatable encryption rule. This idea, a rule-based transformation of symbols, is a conceptual ancestor of later algorithmic thinking in computing.',
        image: 'assets/timeline/caesar-cipher.jpg',
        imageAlt: 'Roman inscription and shifted alphabet concept diagram',
        caption: 'Suggested image: Roman era cipher wheel or Caesar shift alphabet chart.'
    },
    {
        title: 'Al-Kindi And Frequency Analysis (c. 850)',
        body: 'Al-Kindi documented frequency analysis, using statistical patterns in language to break substitution ciphers. This transformed codebreaking from guesswork into methodical analysis, an important step toward data-oriented and computational problem solving.',
        image: 'assets/timeline/al-kindi-frequency.jpg',
        imageAlt: 'Arabic manuscript with letter frequency notes',
        caption: 'Suggested image: historical manuscript or reconstructed frequency table.'
    },
    {
        title: 'Polyalphabetic Cipher Concepts (1467)',
        body: 'Leone Alberti described rotating alphabets, an idea that increased cipher complexity compared with single-shift methods. This shift from simple substitution to changing state is conceptually similar to stateful transformations used in modern computation.',
        image: 'assets/timeline/alberti-disk.jpg',
        imageAlt: 'Alberti cipher disk illustration',
        caption: 'Suggested image: Alberti disk or rotating alphabet diagram.'
    },
    {
        title: 'Vigenere Cipher Popularized (1586)',
        body: 'The Vigenere method became a benchmark of stronger manual encryption by changing shifts through a keyword. It remained influential for centuries and pushed analysts to develop deeper pattern-search strategies.',
        image: 'assets/timeline/vigenere-table.jpg',
        imageAlt: 'Tabula recta for Vigenere encryption',
        caption: 'Suggested image: tabula recta and keyword-based encryption example.'
    },
    {
        title: 'Babbage Breaks Vigenere (1854)',
        body: 'Charles Babbage applied systematic analysis to break the Vigenere cipher long before it became widely known. His approach reinforced the relationship between mathematical methods, data analysis, and proto-computational problem solving.',
        image: 'assets/timeline/babbage-notes.jpg',
        imageAlt: 'Babbage notebooks and analytical diagrams',
        caption: 'Suggested image: Babbage notes or historical cryptanalysis worksheet.'
    },
    {
        title: 'Rotor Machine Era (1917-1920s)',
        body: 'Rotor machines such as Hebern designs and Enigma mechanized complex substitution. Each keypress changed the internal state, creating large keyspaces and operational complexity that demanded more systematic and eventually mechanized codebreaking.',
        image: 'assets/timeline/rotor-machine.jpg',
        imageAlt: 'Electromechanical rotor cipher machine',
        caption: 'Suggested image: Hebern/Enigma machine close-up with rotors visible.'
    },
    {
        title: 'Bletchley Park And Early Machines (1940s)',
        body: 'Codebreakers at Bletchley Park used electromechanical Bombe systems and the electronic Colossus machine to automate parts of cryptanalysis. Their work demonstrated that information problems could be attacked with programmable, machine-driven logic.',
        image: 'assets/timeline/bletchley-colossus.jpg',
        imageAlt: 'Bletchley Park room with Colossus/Bombe equipment',
        caption: 'Suggested image: Bletchley Park operations or Colossus reconstruction.'
    },
    {
        title: 'Information Theory (1948)',
        body: 'Claude Shannon formalized information theory and analyzed secrecy systems mathematically. His work connected communication, probability, and computation, becoming foundational for computer science, digital communication, and modern cryptography.',
        image: 'assets/timeline/shannon-diagram.jpg',
        imageAlt: 'Information source-channel-receiver model diagram',
        caption: 'Suggested image: Shannon communication model or entropy visualization.'
    },
    {
        title: 'Public-Key Breakthrough (1976-1977)',
        body: 'Diffie-Hellman introduced practical key exchange, and RSA provided scalable public-key encryption and signatures. These breakthroughs enabled secure communication between computers that had never shared a secret beforehand.',
        image: 'assets/timeline/public-key.jpg',
        imageAlt: 'Public-key encryption concept with key pairs',
        caption: 'Suggested image: public-key exchange flow diagram.'
    },
    {
        title: 'PGP And Personal Encryption (1991)',
        body: 'Pretty Good Privacy (PGP) brought strong cryptography to personal computers and email, making end-user security practical. It marked a social and technical shift where cryptography moved from state and military contexts into everyday civilian computing.',
        image: 'assets/timeline/pgp-email.jpg',
        imageAlt: 'Encrypted email interface illustration',
        caption: 'Suggested image: PGP keyring screenshot or encrypted email demo.'
    },
    {
        title: 'SSL/TLS Secures The Web (1994-2001)',
        body: 'SSL and later TLS standardized encrypted web sessions, enabling secure shopping, banking, and authentication online. The padlock model became a familiar symbol of trust for mainstream internet users.',
        image: 'assets/timeline/ssl-tls-web.jpg',
        imageAlt: 'Browser lock icon and HTTPS exchange diagram',
        caption: 'Suggested image: HTTPS handshake diagram or early browser security indicator.'
    },
    {
        title: 'Internet Security Age (1990s-Present)',
        body: 'From SSL/TLS to encrypted messaging, cryptography became a core layer of internet computing. Secure protocols now protect software updates, banking, cloud services, identity systems, and private communication across global networks.',
        image: 'assets/timeline/internet-security.jpg',
        imageAlt: 'Modern network security dashboard and encrypted traffic',
        caption: 'Suggested image: modern network map with encrypted channels.'
    }
];

function openTimelineModal(index) {
    if (timelineData[index]) {
        const eventData = timelineData[index];
        const modal = document.getElementById('timelineModal');
        const modalImage = document.getElementById('modalImage');
        const modalCaption = document.getElementById('modalCaption');
        const modalImagePlaceholder = document.getElementById('modalImagePlaceholder');

        document.getElementById('modalTitle').textContent = eventData.title;
        document.getElementById('modalBody').textContent = eventData.body;

        if (modalImage && modalCaption && modalImagePlaceholder) {
            modalCaption.textContent = eventData.caption || 'Image placeholder for this event.';
            modalImage.alt = eventData.imageAlt || 'Timeline event illustration';
            modalImage.style.display = 'block';
            modalImagePlaceholder.style.display = 'none';

            if (eventData.image) {
                modalImage.src = eventData.image;
                modalImage.onerror = function() {
                    modalImage.style.display = 'none';
                    modalImagePlaceholder.style.display = 'flex';
                };
            } else {
                modalImage.removeAttribute('src');
                modalImage.style.display = 'none';
                modalImagePlaceholder.style.display = 'flex';
            }
        }

        modal.style.display = 'block';
    }
}

function closeTimelineModal() {
    document.getElementById('timelineModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('timelineModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}

// ========== CODEBREAKING CHALLENGE ==========
let currentDifficulty = 'easy';
let challengeAttempts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
const maxAttempts = { easy: 5, medium: 3, hard: 2 };

const challengeData = {
    1: { answer: 'HELLO WORLD', hint: 'Simple substitution cipher. Each letter shifts by 3 positions.' },
    2: { answer: 'HELLO WORLD', hint: 'Caesar cipher with shift of 5.' },
    3: { answer: 'ENIGMA ROCKS', hint: 'ROT13 cipher - rotate each letter by 13 positions.' },
    4: { answer: 'BLETCHLEY PARK', hint: 'Atbash cipher - A=Z, B=Y, etc.' },
    5: { answer: 'ALAN TURING', hint: 'A1Z26 number cipher where A=1, B=2, ..., Z=26.' },
    6: { answer: 'CRYPTOGRAPHY', hint: 'Reverse-text cipher. Read from right to left.' }
};

function setDifficulty(difficulty) {
    currentDifficulty = difficulty;
    document.querySelectorAll('.difficulty-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');

    // Add static effect for harder difficulties
    const board = document.getElementById('challengeBoard');
    if (difficulty === 'hard') {
        board.classList.add('static-effect');
    } else {
        board.classList.remove('static-effect');
    }

    // Reset attempts counter
    challengeAttempts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 };
}

function checkAnswer(caseNum, correctAnswer) {
    const userAnswer = document.getElementById('answer' + caseNum).value.toUpperCase().trim();
    const resultDiv = document.getElementById('result' + caseNum);

    challengeAttempts[caseNum]++;
    const attemptsLeft = maxAttempts[currentDifficulty] - challengeAttempts[caseNum];

    if (userAnswer === correctAnswer) {
        resultDiv.textContent = '✓ CORRECT! You successfully decrypted the message.';
        resultDiv.classList.remove('incorrect');
        resultDiv.classList.add('correct');
        document.getElementById('answer' + caseNum).disabled = true;
        document.querySelectorAll(`#dossier${caseNum} .submit-answer`).forEach(btn => btn.disabled = true);
    } else {
        if (attemptsLeft > 0) {
            resultDiv.textContent = `✗ INCORRECT. ${attemptsLeft} attempt${attemptsLeft > 1 ? 's' : ''} remaining.`;
        } else {
            resultDiv.textContent = `✗ FAILED. The answer was: ${correctAnswer}`;
            document.getElementById('answer' + caseNum).disabled = true;
            document.querySelectorAll(`#dossier${caseNum} .submit-answer`).forEach(btn => btn.disabled = true);
        }
        resultDiv.classList.remove('correct');
        resultDiv.classList.add('incorrect');
    }
}

// ========== INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', function() {
    initNavigation();
    showSection('simulator');
});
